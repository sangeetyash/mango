package pageObjects;

public class UserProfile {

	public UserProfile() {
		// TODO Auto-generated constructor stub
	}

}
